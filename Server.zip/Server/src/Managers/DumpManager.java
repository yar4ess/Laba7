package Managers;
import Models.Coordinates;
import Models.Location;
import Models.Movie;
import Models.Person;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Properties;

import static CollectionManager.IDManager.AddId;
import static Managers.PasswordManager.hashPassword;
public class DumpManager {
    private Connection connection;
    public DumpManager(String url, Properties info){
        try {
            connection = DriverManager.getConnection(url, info);
            System.out.println("Successfully connected to the database");
        } catch (SQLException e) {
            System.out.println("Error with connection to DataBase");
        }
    }
    public void initDataBase(){
        createUserTable();
        createTableMovie();
    }
    public void createTableLocation(){
        try {
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE TABLE IF NOT EXISTS Location (\n" +
                    "\tx float,\n" +
                    "\ty float NOT NULL,\n" +
                    "\tz float,\n" +
                    "\tname TEXT NOT NULL,\n" +
                    "\tPRIMARY KEY (x, y, z, name)\n" +
                    ");";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }

    public void createTablePerson(){
        try {
            createTableLocation();
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE TABLE IF NOT EXISTS Person (\n" +
                    "\tname TEXT NOT NULL,\n" +
                    "\tlocation_x float,\n" +
                    "\tlocation_y float NOT NULL,\n" +
                    "\tlocation_z float,\n" +
                    "\tlocation_name TEXT NOT NULL,\n" +
                    "\tbirthday TIMESTAMP NOT NULL,\n" +
                    "\tFOREIGN KEY(location_x, location_y, location_z, location_name) REFERENCES Location(x, y, z, name),\n" +
                    "\tPRIMARY KEY (name, birthday, location_x, location_y, location_z, location_name)\n" +
                    ");";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }

    public void createTableCoordinates(){
        try {
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE TABLE IF NOT EXISTS Coordinates (\n" +
                    "\tx bigint NOT NULL,\n" +
                    "\ty int NOT NULL CHECK (y <= 628),\n" +
                    "\tPRIMARY KEY (x, y) \n" +
                    ");";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }
    public void createTableMovie(){
        createTableCoordinates();
        createTablePerson();
        createIdSeq();
        try {
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE TABLE IF NOT EXISTS Movie (\n" +
                    "\tid int NOT NULL DEFAULT nextval('ID_SEQ'),\n" +
                    "\tname TEXT NOT NULL,\n" +
                    "\tcoordinates_x bigint,\n" +
                    "\tcoordinates_y int NOT NULL,\n" +
                    "\tFOREIGN KEY(coordinates_x, coordinates_y) REFERENCES Coordinates(x, y),\n" +
                    "\tcreationDate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,\n" +
                    "\toscarsCount int CHECK (oscarsCount > 0), \n" +
                    "\tbudget float NOT NULL CHECK (budget > 0),\n" +
                    "\ttagline TEXT NOT NULL,\n" +
                    "\tgenre TEXT NOT NULL,\n" +
                    "\tscreenwriterName TEXT NOT NULL,\n" +
                    "\tscreenwriterBirthday TIMESTAMP NOT NULL,\n" +
                    "\tlocation_x float,\n" +
                    "\tlocation_y float NOT NULL,\n" +
                    "\tlocation_z float,\n" +
                    "\tlocation_name TEXT NOT NULL,\n" +
                    "\tFOREIGN KEY (screenwriterName, screenwriterBirthday, location_x, location_y, location_z, location_name) REFERENCES\n" +
                    "\tPerson(name, birthday, location_x, location_y, location_z, location_name),\n" +
                    "\tuser_name TEXT,"
                    + "FOREIGN KEY (user_name) REFERENCES users(user_name)" +
                    ");";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }
    public void createUserTable(){
        try {
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE TABLE IF NOT EXISTS USERS " +
                    "(user_name TEXT PRIMARY KEY, " +
                    " password TEXT);";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }
    public void createIdSeq(){
        try {
            Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            String sql = "CREATE SEQUENCE IF NOT EXISTS ID_SEQ START WITH 1 INCREMENT BY 1;";
            statement.executeUpdate(sql);
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error sending request");
        }
    }
    public boolean checkUser(String user_name){
        boolean exists = false;
        ResultSet resultSet;
        PreparedStatement preparedStatement;
        try {
            String sql = "SELECT COUNT(*) AS count FROM users WHERE user_name = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, user_name);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                if (count > 0) {
                    exists = true;
                }
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            System.out.println("Error with sql(");
        }
        return exists;
    }
    public void registerUser(String user_name, String pswd){
        PreparedStatement preparedStatement = null;
        try {
            String sql = "INSERT INTO users (user_name, password) VALUES (?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, user_name);
            preparedStatement.setString(2, pswd);
            preparedStatement.executeUpdate();
            System.out.println("User added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding user registration");
        }
        finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                System.out.println("Error with closing statement");
            }
        }
    }
    public boolean checkPassword(String user_name, String pswd) {
        String sql = "SELECT password FROM Users WHERE user_name = ?";
        PreparedStatement prepareStatement;
        try {
            prepareStatement = connection.prepareStatement(sql);
            prepareStatement.setString(1, user_name);
            ResultSet resultSet = prepareStatement.executeQuery();
            if (resultSet.next()) {
                String hashedPassword = resultSet.getString("password");
                String hashedInputPassword = hashPassword(pswd);
                prepareStatement.close();
                resultSet.close();
                return hashedInputPassword.equals(hashedPassword);
            }
            prepareStatement.close();
            resultSet.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return false;
    }
    public ArrayList<String> getUsers() {
        String sql = "SELECT user_name FROM Users;";
        PreparedStatement prepareStatement;
        ArrayList<String> users = new ArrayList<>();
        try {
            prepareStatement = connection.prepareStatement(sql);
            ResultSet resultSet = prepareStatement.executeQuery();
            while (resultSet.next()) {
                String user = resultSet.getString("user_name");
                users.add(user);
            }
            if (!users.isEmpty()){
                prepareStatement.close();
                resultSet.close();
            } else {
                users.add("There are no users yet...");
                return users;
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return users;
    }
    public LinkedList<Movie> readFromDataBase(){
        PreparedStatement preparedStatement;
        LinkedList<Movie> movies = new LinkedList<>();
        try {
            String sql = "SELECT * FROM Movie";
            preparedStatement = connection.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                Coordinates coordinates = new Coordinates();
                movie.setId(rs.getInt("id"));
                AddId(rs.getInt("id"));
                movie.setName(rs.getString("name"));
                coordinates.setX(rs.getLong("coordinates_x"));
                coordinates.setY(rs.getInt("coordinates_y"));
                movie.setCoordinates(coordinates);
                movie.setCreationDate(rs.getTimestamp("creationDate"));
                movie.setOscarsCount(rs.getInt("oscarsCount"));
                movie.setBudget(rs.getDouble("budget"));
                movie.setTagline(rs.getString("tagline"));
                movie.setGenre(CastManager.castToDragonType(rs.getString("genre")));
                Location location = new Location();
                location.setX(rs.getFloat("location_x"));
                location.setY(rs.getFloat("location_y"));
                location.setX(rs.getFloat("location_x"));
                location.setName(rs.getString("location_name"));
                Person person = new Person();
                person.setLocation(location);
                person.setBirthday(rs.getTimestamp("screenwriterBirthday").toLocalDateTime().toLocalDate());
                person.setName(rs.getString("screenwriterName"));
                movie.setUser_name(rs.getString("user_name"));
                movie.setScreenwriter(person);
                movies.add(movie);
            }
            rs.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }
    public void saveToDataBase(LinkedList<Movie> movies, String user_name){
        StringBuilder sql = new StringBuilder("DELETE FROM Movie WHERE user_name = ?;");
        PreparedStatement prepareStatement;
        for (Movie movie: movies){
            if (movie.getUser_name().equals(user_name)){
                if (!movie.getUser_name().isEmpty()){
                    var value = getValue(movie);
                    sql.append(value);
                }
            }
        }
        try {
            prepareStatement = connection.prepareStatement(sql.toString());
            prepareStatement.setString(1, user_name);
            prepareStatement.executeQuery();
            prepareStatement.close();
        } catch (SQLException ex) {
            System.out.println("saved");
        }
    }
    private static String getValue(Movie movie) {
        // используем в методе выше
        String value = "INSERT INTO Coordinates(x, y)" +
                "VALUES (" + movie.getCoordinates().getX() + "," + movie.getCoordinates().getY()+ ") ON CONFLICT (x, y) DO NOTHING;";
        value += "INSERT INTO Location(x, y, z, name)" +
                "VALUES (" + movie.getScreenWriter().getLocation().getX() + "," + movie.getScreenWriter().getLocation().getY() + ", "
                + movie.getScreenWriter().getLocation().getZ() + ", " + "'" + movie.getScreenWriter().getLocation().getName() + "'" +") ON CONFLICT (x, y, z, name) DO NOTHING;";
        value += "INSERT INTO Person(name, birthday, location_x, location_y, location_z, location_name)" +
                "VALUES (" + "'" +movie.getScreenWriter().getName() + "'" + ", " + "'" + movie.getScreenWriter().getBirthday() + "'" + ", " + movie.getScreenWriter().getLocation().getX() + "," + movie.getScreenWriter().getLocation().getY() + ", " +
                movie.getScreenWriter().getLocation().getZ() + ", " + "'" + movie.getScreenWriter().getLocation().getName() + "'" +") ON CONFLICT (name, birthday, location_x, location_y, location_z, location_name) DO NOTHING;";
        value += "INSERT INTO Movie(id, name, coordinates_x, coordinates_y, creationDate, oscarsCount, budget, tagline, genre, screenwriterName, " +
                "screenwriterBirthday, location_x, location_y, location_z, location_name, user_name)" +
                "VALUES";
        value += "(" + movie.getId() + "," + "'" + movie.getName() + "'" + "," + movie.getCoordinates().getX() + "," + movie.getCoordinates().getY()
                + "," + "'" + movie.getCreationDate() + "'" +  "," + movie.getOscarsCount() + "," + movie.getBudget() + "," + "'" + movie.getTagline() + "'" + ","
                + "'" + movie.getGenre() + "'" + "," + "'" + movie.getScreenWriter().getName() + "'" + "," + "'" + movie.getScreenWriter().getBirthday() + "'" + ", " +
                movie.getScreenWriter().getLocation().getX() + ", " +
                movie.getScreenWriter().getLocation().getY() + ", " +
                movie.getScreenWriter().getLocation().getZ() + ", " +
                "'" + movie.getScreenWriter().getLocation().getName() + "'" + ", " +
                "'" + movie.getUser_name() + "'" + ");";
        return value;
    }
}
