package Server;
import CommandManager.CommandManager;
import Managers.DumpManager;
import Managers.PasswordManager;
import Response.*;
import Launcher.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.*;

public class Server {
    private static final Logger logger = Logger.getLogger(Server.class.getName());
    private final int port;
    private final CommandManager commandManager;
    private LaunchCommand launchCommand;
    private final Map<SocketChannel, ObjectOutputStream> clients;
    private final ExecutorService requestThreadPool;
    private final ExecutorService responseThreadPool;
    private final ReadWriteLock clientsLock;
    private final DumpManager dumpManager;
    public Server(int port, CommandManager commandManager, String propPath, DumpManager dumpManager) {
        this.port = port;
        this.commandManager = commandManager;
        this.launchCommand = new LaunchCommand(commandManager);
        this.dumpManager = dumpManager;
        clients = new HashMap<>();
        requestThreadPool = Executors.newCachedThreadPool();
        responseThreadPool = Executors.newFixedThreadPool(228);
        clientsLock = new ReentrantReadWriteLock();
        System.setProperty("java.util.logging.config.file", propPath);
    }

    public void start() throws IOException {
        logger.info("Starting the server");
        ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.bind(new InetSocketAddress("localhost", port));
        while (true) {
            logger.info("Waiting for client connection");
            SocketChannel clientChannel = serverSocketChannel.accept();
            clientsLock.writeLock().lock();
            try {
                ObjectOutputStream oos = new ObjectOutputStream(clientChannel.socket().getOutputStream());
                clients.put(clientChannel, oos);
            } finally {
                clientsLock.writeLock().unlock();
            }
            requestThreadPool.execute(() -> handleClient(clientChannel));
        }
    }

    private void handleClient(SocketChannel clientChannel) {
        try {
            ObjectInputStream ois = new ObjectInputStream(clientChannel.socket().getInputStream());
            while (true) {
                try {
                    Response message = (Response) ois.readObject();
                    logger.info("Received a request");
                    if (message.getStatus().equals(STATUS.COMMAND)) {
                        Response commandResult = launchCommand.commandParser(message.getMessage(), message.getObject());
                        sendResponse(clientChannel, commandResult);
                    } else if (message.getStatus().equals(STATUS.USERCHECK)) {
                        Response commandResult;
                        switch (message.getMessage()) {
                            case "checkUser" -> {
                                commandResult = new Response(STATUS.USERCHECK, "", dumpManager.checkUser((String) message.getObject()));
                                sendResponse(clientChannel, commandResult);
                            }
                            case "registerUser" -> {
                                String data = (String) message.getObject();
                                dumpManager.registerUser(data.split(" ")[0], PasswordManager.hashPassword((data.split(" ")[1])));
                                commandResult = new Response(STATUS.USERCHECK, "Пользователь зарегистрирован");
                                commandManager.setUserStatusManager(data.split(" ")[0], true);
                                sendResponse(clientChannel, commandResult);
                            }
                            case "checkPassword" -> {
                                String data = (String) message.getObject();
                                commandResult = new Response(STATUS.USERCHECK, "", dumpManager.checkPassword(data.split(" ")[0], (data.split(" ")[1])));
                                System.out.println(dumpManager.checkPassword(data.split(" ")[0], (data.split(" ")[1])));
                                if (dumpManager.checkPassword(data.split(" ")[0], (data.split(" ")[1]))){
                                    commandManager.setUserStatusManager(data.split(" ")[0], true);
                                }
                                sendResponse(clientChannel, commandResult);
                            }
                            case "logout" -> commandManager.setUserStatusManager("", false);
                        }
                    } else {
                        Response commandResult = launchCommand.doCommand("save", "", "");
                        sendResponse(clientChannel, commandResult);
                    }
                } catch (IOException e) {
                    logger.info("Client disconnected");
                    clientsLock.writeLock().lock();
                    try {
                        clients.remove(clientChannel);
                    } finally {
                        clientsLock.writeLock().unlock();
                    }
                    break;
                } catch (ClassNotFoundException e) {
                    logger.log(Level.SEVERE, "Error reading object from client", e);
                }
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error handling client", e);
        }
    }

    private void sendResponse(SocketChannel clientChannel, Response response) {
        clientsLock.readLock().lock();
        try {
            ObjectOutputStream oos = clients.get(clientChannel);
            responseThreadPool.execute(() -> {
                try {
                    logger.info("Sending response to client");
                    oos.writeObject(response);
                    oos.flush();
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Error sending response to client", e);
                }
            });
        } finally {
            clientsLock.readLock().unlock();
        }
    }
}
