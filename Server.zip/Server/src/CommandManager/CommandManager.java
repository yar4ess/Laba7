package CommandManager;
import Managers.UserStatusManager;

import java.util.HashMap;
import java.util.Map;
/**
 * Отвечает за выполнение связь между названием и описанием команды, названием и выполнением
 */
public class CommandManager {
    public CommandManager(UserStatusManager userStatusManager){
        this.userStatusManager = userStatusManager;
    }
    private final UserStatusManager userStatusManager;
    private final Map<String, String> CommandList = new HashMap<>();
    private final Map<String, Command> Commands = new HashMap<>();
    public Map<String, String> getCommandList() {
        return CommandList;
    }
    public UserStatusManager getUserStatusManager(){
        return userStatusManager;
    }
    public void setUserStatusManager(String user_name, boolean status){
        userStatusManager.setUser_name(user_name);
        userStatusManager.setStatus(status);
    }

    /**
     * @return Возвращает Map<название команды, команда>
     */
    public Map<String, Command> getCommands() {
        return Commands;
    }

    /**
     * Добавляет в Map<название команды, команда> новый элемент
     */
    public void addCommand(String name, Command command){
        Commands.put(name, command);
    }
    /**
     * Добавляет в Map<название команды, описание команды> новый элемент
     */
    public void addCommandList(String name, String description){
        CommandList.put(name, description);
    }

}
