package Models;
/**
 * Интерефейс проверяет валидность полей элементов коллекции
 */
public interface Validatable {
    boolean validate();
}
